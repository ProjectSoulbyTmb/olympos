import argparse
import json
import os
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from mind import engineer, moderator, releaser  # noqa: E402
from mind.state import MindState  # noqa: E402


def root_arg(argv):
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("--root", default=None)
    args, _ = ap.parse_known_args(argv)
    root = args.root or os.environ.get("OSRS_ROOT")
    if not root:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.abspath(root)


def cmd_status(root, state):
    findings = moderator.patrol(root)
    version = releaser.read_version(root)
    dirty = releaser.git_dirty(root)
    tags = releaser._git(root, "tag", "--list").stdout.split()
    status = {
        "version": version,
        "latest_tag": sorted(tags)[-1] if tags else None,
        "working_tree_dirty": dirty,
        "findings": [f.as_dict() for f in findings],
        "critical": sum(1 for f in findings if f.severity == "critical"),
        "auto_fixed": sum(1 for f in findings if f.action == "auto-fixed"),
        "recent_events": state.recent(15),
    }
    state.write_status(status)
    print(f"MIND status for {os.path.basename(root)}")
    print(f"  version      : {version} "
          f"(tag: {status['latest_tag']}, dirty: {dirty})")
    print(f"  findings     : {len(findings)} "
          f"(critical={status['critical']}, auto-fixed={status['auto_fixed']})")
    for f in findings:
        print(f"    {f}")
    return 2 if status["critical"] else 0


def cmd_patrol(root, state, loop=0, llm=False, base_url=None, model=None,
               skip_tests=False):
    while True:
        t0 = time.time()
        state.log("moderator", "patrol-start")
        findings = moderator.patrol(root)
        fixed = sum(1 for f in findings if f.action == "auto-fixed")
        critical = [f for f in findings if f.severity == "critical"]
        state.log("moderator", "patrol-done",
                  f"{len(findings)} findings, {fixed} auto-fixed")
        test_result = {"ok": True, "ran": 0}
        if not critical and not skip_tests:
            state.log("engineer", "tests-start")
            test_result = engineer.run_tests(root)
            state.log("engineer", "tests-done",
                      f"ok={test_result['ok']} ran={test_result['ran']} "
                      f"({test_result['duration_s']}s)")
            if not test_result["ok"]:
                advice = engineer.diagnose(test_result)
                for a in advice:
                    state.log("engineer", "diagnosis",
                              f"[{a['kind']}] {a['fix']}")
                healed = engineer.auto_heal(root, state)
                for h in healed:
                    state.log("engineer", "healed", h)
                if llm and all(a["kind"] != "auto-fixable" for a in advice):
                    result = engineer.llm_diagnose(root, test_result,
                                                   base_url, model)
                    state.log("engineer", "llm-proposal",
                              result.get("saved", result.get("error", "")))
        state.write_status({
            "last_patrol": time.time(),
            "patrol_seconds": round(time.time() - t0, 1),
            "findings": [f.as_dict() for f in findings],
            "tests_ok": test_result["ok"],
            "tests_ran": test_result.get("ran", 0),
            "healthy": not critical and test_result["ok"],
        })
        if loop <= 0:
            return 0 if (test_result["ok"] and not critical) else 1
        time.sleep(loop * 60)


def cmd_update_data(root, state):
    tool = os.path.join(root, "tools", "update_knowledge.py")
    state.log("engineer", "data-refresh-start")
    proc = subprocess.run([sys.executable, tool], cwd=root,
                          capture_output=True, text=True,
                          errors="replace", timeout=600,
                          creationflags=subprocess.CREATE_NO_WINDOW)
    ok = proc.returncode == 0
    state.log("engineer", "data-refresh-done", f"ok={ok}")
    if not ok:
        state.log("engineer", "data-refresh-error",
                  (proc.stderr or "")[-500:])
    return 0 if ok else 1


def cmd_release(root, state, level="patch", dry_run=False, no_build=False):
    plan = releaser.release(root, level=level, dry_run=dry_run,
                            do_build=not no_build,
                            log=lambda m: state.log("releaser", "build", m))
    print(json.dumps({k: v for k, v in plan.items() if k != "changelog"},
                     indent=1))
    if dry_run:
        print("\nproposed changelog:")
        for b in plan.get("changelog", []):
            print(f"  {b}")
        return 0
    if plan.get("error"):
        state.log("releaser", "release-failed", plan["error"])
        return 1
    state.log("releaser", "released",
              f"{plan['current']} -> {plan['target']}"
              + (f" zip={plan['zip']}" if plan.get("zip") else ""))
    return 0


def cmd_install_tasks(root, state):
    py = sys.executable
    daemon = os.path.join(root, "mind", "daemon.py")
    tasks = [
        ("OSRS Mind Patrol",
         [py, "-m", "mind.daemon", "--root", root, "patrol"], "HOURLY"),
        ("OSRS Knowledge Refresh",
         [py, os.path.join(root, "tools", "update_knowledge.py")], "HOURLY"),
    ]
    results = []
    for name, cmd_parts, sched in tasks:
        tr = " ".join(f'"{p}"' if " " in p else p for p in cmd_parts)
        r = subprocess.run(["schtasks", "/Create", "/F", "/TN", name,
                            "/TR", tr, "/SC", sched],
                           capture_output=True, text=True)
        ok = r.returncode == 0
        results.append((name, ok, (r.stderr or "").strip()))
        state.log("moderator", "install-task", f"{name}: ok={ok}")
    for name, ok, err in results:
        print(f"  {'OK ' if ok else 'ERR'} {name}"
              + (f" - {err}" if err else ""))
    failed = [r for r in results if not r[1]]
    if any("Access is denied" in e.lower() for _, _, e in failed):
        print("\nrun this shell as Administrator to register tasks")
    return 0 if all(ok for _, ok, _ in results) else 1


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    root = root_arg(argv)
    state = MindState(root)
    rest = argv
    for flag in ("--root",):
        if flag in rest:
            i = rest.index(flag)
            del rest[i:i + 2]
    cmd = rest[0] if rest else "status"
    rest = rest[1:]

    ap = argparse.ArgumentParser(prog="osrs mind")
    ap.add_argument("--loop", type=int, default=0, metavar="MINUTES",
                    help="keep patrolling every N minutes")
    ap.add_argument("--llm", action="store_true",
                    help="consult local LLM for unexplained failures")
    ap.add_argument("--base-url", default=None)
    ap.add_argument("--model", default=None)
    ap.add_argument("--level", choices=["patch", "minor", "major"],
                    default="patch")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--no-build", action="store_true")
    ap.add_argument("--skip-tests", action="store_true")
    a, extra = ap.parse_known_args(rest)

    if cmd == "status":
        return cmd_status(root, state)
    if cmd == "patrol":
        return cmd_patrol(root, state, loop=a.loop, llm=a.llm,
                          base_url=a.base_url, model=a.model,
                          skip_tests=a.skip_tests or bool(extra))
    if cmd == "update-data":
        return cmd_update_data(root, state)
    if cmd == "release":
        return cmd_release(root, state, level=a.level, dry_run=a.dry_run,
                           no_build=a.no_build)
    if cmd == "install-tasks":
        return cmd_install_tasks(root, state)
    print(f"unknown command '{cmd}' - use status|patrol|update-data|"
          "release|install-tasks")
    return 2


if __name__ == "__main__":
    sys.exit(main())
